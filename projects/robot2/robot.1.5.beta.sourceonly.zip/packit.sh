#!/bin/bash

zip -9 robot.1.5.beta.sourceonly.zip * -x *.zip *.rar backup robot robot.exe \
&& rar a -m5 robot.1.5.beta.sourceonly.rar -x*.zip -x*.rar -xbackup -xrobot -xrobot.exe * \
&& rar a -m5 robot.1.5.beta.rar -x*.zip -x*.rar -xbackup *
