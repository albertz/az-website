#!/bin/bash

rsync -avP *.rar root@server.az2000.de:/var/www/localhost/htdocs/projects/robot2/
