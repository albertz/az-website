//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDD_MAIN                        101
#define IDR_MENU1                       102
#define CMD_COMPILE                     1000
#define IDC_TXT_FRONTIMAGE              1001
#define IDC_FRONTBROWSE                 1002
#define IDC_TXT_BACKIMAGE               1003
#define IDC_BACKBROWSE                  1004
#define IDC_TXT_MATIMAGE                1005
#define IDC_MATBROWSE                   1006
#define IDC_TXT_LEVELNAME               1007
#define IDC_TXT_PREVIMAGE               1008
#define IDC_PVWBROWSE                   1009
#define IDC_TXT_LXLFILE                 1010
#define IDC_LXLBROWSE                   1011
#define IDC_CHKWATER                    1012
#define MNU_HELP_ABOUT                  40001
#define MNU_FILE_EXIT                   40002
#define MNU_FILE_LOADPRJ                40003
#define MNU_FILE_SAVEPRJ                40004
#define MNU_FILE_SAVEASPRJ              40005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
