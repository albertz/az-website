/////////////////////////////////////////
//
//             Liero Xtreme
//
//     Copyright Auxiliary Software 2002
//
//
/////////////////////////////////////////


// Command structure
// Created 22/7/02
// Jason Boettcher


#ifndef __COMMAND_H__
#define __COMMAND_H__


// Command flags
#define		CMD_POSITION	0x01
#define		CMD_ANGLE		0x02


// Command structure
/*typedef struct {

	int		iFlags;

	int		iDirection;
	int		iCarve;
	int		iShoot;
	int		iWeapon;
	int		iX, iY;
	int		iAngle;

} command_t;*/




#endif  //  __COMMAND_H__