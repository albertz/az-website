Liero v1.11
Mod for LieroX 0.56b/0.57b 2004-05-26


This mod is made by Strider and HocusPocus, with bug testing help of Gliptic and many others in #LieroX.

It tried to be as near original game as possible but still have some better balancing and some graphical upgrades so it fits to LieroX.

This mod is greatly changed since version 1.0. Added damage delay so non-hosts won't hit themselves when they move forwards and shoot.

Note: It's balanced in 100% reload time and used the no-explosions feature from LX 0.56b. So it does not work that good in 0% reload time and LieroX 0.55b.

This is the thread for this mod, here you can give feedback and read news:
http://forums.thegaminguniverse.com/showthread.php?t=14324
