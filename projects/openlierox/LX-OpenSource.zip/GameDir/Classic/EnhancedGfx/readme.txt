Enhanced Graphics by Strider

Put these image files into the gfx directory in the classic mod to replace the old graphics.

