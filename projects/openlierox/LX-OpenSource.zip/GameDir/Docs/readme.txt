Liero Xtreme v0.55b
By Auxiliary Software 2002-2003

http://lieroxtreme.thegaminguniverse.com

28th October 2003
-------------------------------------



Contents
1) Description
2) Installation
3) How to play
4) Parameters
5) Contact
6) Credits




1) Description
Liero Xtreme is a somewhere between a clone and a sequel of the original classic game Liero.
Liero Xtreme trys to keep some of the core gameplay features of Liero, while adding a new frontend menu system, an integrated map editor, network play and easier modibility.

The object of the game is to kill the enemy or be killed. To help you achieve your objective, you are given a range of weapons to select from.

Liero Xtreme is freeware, and may be distributed freely on a couple conditions:
1) The contents of the package remain unchanged
2) The game is not sold commercially (ask permission for this one)




2) Installation
Just unzip the contents of the zip file into a directory. Make sure directories are unzipped too.
Run LieroX.exe to play the game.




3) How to play
If you've never played the original Liero, look in the docs directory in the directory you installed Liero Xtreme to. Open the file 'main.htm' in your browser and follow the links.


4) Parameters
The following parameters can be used to alter settings in Liero Xtreme
Usage:
LieroX.exe [parameters]

Note: The parameters below also alter the settings in Liero Xtreme
(eg, -nosound also sets the sound to 'off' in the system settings)

-nosound
Disables sound

-window
Uses window (ie, not fullscreen)

-fullscreen
Uses fullscreen


5) Contact

Liero Xtreme site:
http://lieroxtreme.xp8.com/

My email address:
jasonb___@hotmail.com




6) Credits

Programming:
Jason Boettcher

Testing:
Luke Graham